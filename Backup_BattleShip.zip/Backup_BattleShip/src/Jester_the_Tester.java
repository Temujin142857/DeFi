public class Jester_the_Tester {
    public static void main(String[] args) {
        UI ui=new UI();
        ui.run();
    }
}
